"""
Anatomically-Localized False-Positive Rate Evaluation
=====================================================
Computes OD-adjacent exudate FPR and vessel-adjacent hemorrhage FPR.

Equations from the paper:
    FPR_OD = FP(EX ∩ R_OD) / [FP(EX ∩ R_OD) + TN(EX ∩ R_OD)]     (Eq. 16)
    FPR_V  = FP(HE ∩ R_V)  / [FP(HE ∩ R_V)  + TN(HE ∩ R_V)]      (Eq. 17)

Region definitions:
    - OD-adjacent region: 15-pixel dilated optic-disc mask excluding disc interior
    - Vessel-adjacent region: 5-pixel dilated vessel mask excluding vessel pixels
    - Lesion probability threshold: 0.50

Usage:
    python eval_fpr.py \
        --pred_dir results/predictions/ \
        --gt_dir data/refined_idrid/masks/ \
        --prior_dir data/priors/ \
        --split_file splits/test_ids.txt
"""

import argparse
import os
import numpy as np
from collections import defaultdict

try:
    from scipy.ndimage import binary_dilation
    from skimage.morphology import disk
except ImportError:
    raise ImportError("scipy and scikit-image required. Install via: "
                      "pip install scipy scikit-image")


# ---- Constants ----
OD_DILATION_PX = 15        # Pixels to dilate OD mask
VESSEL_DILATION_PX = 5     # Pixels to dilate vessel mask
PROB_THRESHOLD = 0.50      # Lesion probability threshold

# Class indices in the 12-class segmentation schema
CLASS_EX = 3   # Hard Exudates
CLASS_HE = 2   # Hemorrhages
CLASS_OD = 8   # Optic Disc
CLASS_VE = 9   # Retinal Vessels


def load_split_ids(split_file):
    """Load image IDs from a split file, ignoring comments and blank lines."""
    ids = []
    with open(split_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                ids.append(line)
    return ids


def create_od_adjacent_region(od_mask, dilation_px=OD_DILATION_PX):
    """
    Create the OD-adjacent region: dilated OD mask minus OD interior.

    Args:
        od_mask: Binary optic disc mask (H, W)
        dilation_px: Number of pixels to dilate

    Returns:
        Binary mask of OD-adjacent region (H, W)
    """
    structuring_element = disk(dilation_px)
    dilated = binary_dilation(od_mask.astype(bool), structure=structuring_element)
    adjacent_region = dilated & ~od_mask.astype(bool)
    return adjacent_region.astype(np.float32)


def create_vessel_adjacent_region(vessel_mask, dilation_px=VESSEL_DILATION_PX):
    """
    Create the vessel-adjacent region: dilated vessel mask minus vessel pixels.

    Args:
        vessel_mask: Binary vessel mask (H, W)
        dilation_px: Number of pixels to dilate

    Returns:
        Binary mask of vessel-adjacent region (H, W)
    """
    structuring_element = disk(dilation_px)
    dilated = binary_dilation(vessel_mask.astype(bool), structure=structuring_element)
    adjacent_region = dilated & ~vessel_mask.astype(bool)
    return adjacent_region.astype(np.float32)


def compute_regional_fpr(pred_prob, gt_mask, region_mask, target_class, threshold=PROB_THRESHOLD):
    """
    Compute false-positive rate within a specified anatomical region.

    For exudate FPR in OD region (Eq. 16):
        FPR = FP(EX ∩ R_OD) / [FP(EX ∩ R_OD) + TN(EX ∩ R_OD)]

    Args:
        pred_prob: Predicted probability map for target class (H, W)
        gt_mask: Ground truth segmentation labels (H, W)
        region_mask: Binary mask defining the anatomical region (H, W)
        target_class: Class index to evaluate
        threshold: Probability threshold for positive prediction

    Returns:
        FPR value (float), or np.nan if region has no evaluable pixels
    """
    # Restrict to the anatomical region
    region_pixels = region_mask.astype(bool)

    if np.sum(region_pixels) == 0:
        return np.nan

    # Within the region: predicted positive and ground-truth labels
    pred_positive = (pred_prob[region_pixels] >= threshold)
    gt_positive = (gt_mask[region_pixels] == target_class)

    # False positives: predicted positive but ground truth negative
    fp = np.sum(pred_positive & ~gt_positive)
    # True negatives: predicted negative and ground truth negative
    tn = np.sum(~pred_positive & ~gt_positive)

    denominator = fp + tn
    if denominator == 0:
        return np.nan

    return fp / denominator


def evaluate_fpr(pred_dir, gt_dir, prior_dir, split_ids):
    """
    Evaluate OD-adjacent and vessel-adjacent false-positive rates.

    Args:
        pred_dir: Directory with prediction probability maps (.npy, shape H×W×C)
        gt_dir: Directory with ground truth segmentation masks (.npy, shape H×W)
        prior_dir: Directory with anatomical prior maps
        split_ids: List of image IDs

    Returns:
        Dictionary with per-image and aggregate FPR results
    """
    od_fpr_list = []
    vessel_fpr_list = []
    overall_fp_total = 0
    overall_fp_tn_total = 0

    per_image_results = {}

    for img_id in split_ids:
        # Load prediction probabilities (H, W, C)
        pred_path = os.path.join(pred_dir, f"{img_id}_prob.npy")
        gt_path = os.path.join(gt_dir, f"{img_id}_mask.npy")
        od_prior_path = os.path.join(prior_dir, f"{img_id}_od.npy")
        vessel_prior_path = os.path.join(prior_dir, f"{img_id}_vessel.npy")

        if not all(os.path.exists(p) for p in [pred_path, gt_path, od_prior_path, vessel_prior_path]):
            print(f"Warning: Missing files for {img_id}, skipping.")
            continue

        pred_prob = np.load(pred_path)   # (H, W, C) softmax probabilities
        gt_mask = np.load(gt_path)       # (H, W) integer labels
        od_mask = np.load(od_prior_path) # (H, W) binary OD mask
        vessel_mask = np.load(vessel_prior_path)  # (H, W) binary vessel mask

        # Create adjacent regions
        od_adjacent = create_od_adjacent_region(od_mask, OD_DILATION_PX)
        vessel_adjacent = create_vessel_adjacent_region(vessel_mask, VESSEL_DILATION_PX)

        # OD-adjacent exudate FPR (Eq. 16)
        od_fpr = compute_regional_fpr(
            pred_prob[:, :, CLASS_EX], gt_mask, od_adjacent,
            target_class=CLASS_EX, threshold=PROB_THRESHOLD
        )

        # Vessel-adjacent hemorrhage FPR (Eq. 17)
        vessel_fpr = compute_regional_fpr(
            pred_prob[:, :, CLASS_HE], gt_mask, vessel_adjacent,
            target_class=CLASS_HE, threshold=PROB_THRESHOLD
        )

        per_image_results[img_id] = {
            'od_fpr': od_fpr,
            'vessel_fpr': vessel_fpr,
        }

        if not np.isnan(od_fpr):
            od_fpr_list.append(od_fpr)
        if not np.isnan(vessel_fpr):
            vessel_fpr_list.append(vessel_fpr)

    # Aggregate statistics
    od_fpr_arr = np.array(od_fpr_list)
    vessel_fpr_arr = np.array(vessel_fpr_list)

    results = {
        'per_image': per_image_results,
        'od_adjacent_fpr': {
            'mean': np.mean(od_fpr_arr) if len(od_fpr_arr) > 0 else np.nan,
            'median': np.median(od_fpr_arr) if len(od_fpr_arr) > 0 else np.nan,
            'q1': np.percentile(od_fpr_arr, 25) if len(od_fpr_arr) > 0 else np.nan,
            'q3': np.percentile(od_fpr_arr, 75) if len(od_fpr_arr) > 0 else np.nan,
            'n_images': len(od_fpr_arr),
        },
        'vessel_adjacent_fpr': {
            'mean': np.mean(vessel_fpr_arr) if len(vessel_fpr_arr) > 0 else np.nan,
            'median': np.median(vessel_fpr_arr) if len(vessel_fpr_arr) > 0 else np.nan,
            'q1': np.percentile(vessel_fpr_arr, 25) if len(vessel_fpr_arr) > 0 else np.nan,
            'q3': np.percentile(vessel_fpr_arr, 75) if len(vessel_fpr_arr) > 0 else np.nan,
            'n_images': len(vessel_fpr_arr),
        },
    }

    return results


def print_results(results):
    """Print formatted FPR results."""
    print("=" * 65)
    print("FALSE-POSITIVE RATE IN ANATOMICALLY SENSITIVE REGIONS")
    print("=" * 65)

    od = results['od_adjacent_fpr']
    ve = results['vessel_adjacent_fpr']

    print(f"\nOD-Adjacent Exudate FPR (Eq. 16):")
    print(f"  Mean:   {od['mean']:.4f}")
    print(f"  Median: {od['median']:.4f} (IQR: {od['q1']:.3f}–{od['q3']:.3f})")
    print(f"  N:      {od['n_images']} images")

    print(f"\nVessel-Adjacent Hemorrhage FPR (Eq. 17):")
    print(f"  Mean:   {ve['mean']:.4f}")
    print(f"  Median: {ve['median']:.4f} (IQR: {ve['q1']:.3f}–{ve['q3']:.3f})")
    print(f"  N:      {ve['n_images']} images")

    print(f"\nPer-Image OD-Adjacent FPR:")
    print(f"  {'Image ID':<20} {'OD FPR':<12} {'Vessel FPR':<12}")
    print(f"  {'-'*44}")
    for img_id, vals in sorted(results['per_image'].items()):
        od_v = f"{vals['od_fpr']:.4f}" if not np.isnan(vals['od_fpr']) else "N/A"
        ve_v = f"{vals['vessel_fpr']:.4f}" if not np.isnan(vals['vessel_fpr']) else "N/A"
        print(f"  {img_id:<20} {od_v:<12} {ve_v:<12}")

    print("=" * 65)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Evaluate anatomically-localized false-positive rates"
    )
    parser.add_argument("--pred_dir", type=str, required=True,
                        help="Directory with prediction probability maps")
    parser.add_argument("--gt_dir", type=str, required=True,
                        help="Directory with ground truth masks")
    parser.add_argument("--prior_dir", type=str, required=True,
                        help="Directory with anatomical prior maps")
    parser.add_argument("--split_file", type=str, required=True,
                        help="Path to split file with image IDs")

    args = parser.parse_args()

    split_ids = load_split_ids(args.split_file)
    print(f"Evaluating FPR for {len(split_ids)} images...")

    results = evaluate_fpr(args.pred_dir, args.gt_dir, args.prior_dir, split_ids)
    print_results(results)
