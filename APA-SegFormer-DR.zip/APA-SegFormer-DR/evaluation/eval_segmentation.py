"""
Segmentation Evaluation Script for APA-SegFormer
=================================================
Computes: mDice, mIoU, per-class Dice, AUPR, HD95

Paper: Transformer-Based Diabetic Retinopathy Segmentation and Grading:
       Anatomical Prior Attention for False-Positive Suppression

Usage:
    python eval_segmentation.py \
        --pred_dir results/predictions/ \
        --gt_dir data/refined_idrid/masks/ \
        --split_file splits/test_ids.txt \
        --num_classes 12
"""

import argparse
import os
import numpy as np
from glob import glob
from collections import defaultdict

try:
    from sklearn.metrics import average_precision_score
    from scipy.ndimage import distance_transform_edt
    from skimage import io
except ImportError as e:
    raise ImportError(f"Missing dependency: {e}. Install via: pip install scikit-learn scipy scikit-image")


# ---- Class Definitions ----
CLASS_NAMES = [
    "Background",              # 0
    "Microaneurysms (MA)",     # 1
    "Hemorrhages (HE)",        # 2
    "Hard Exudates (EX)",      # 3
    "Cotton-Wool Spots (CWS)", # 4
    "Neovascularization (NV)", # 5
    "Vitreous Hemorrhage (VH)",# 6
    "IRMA",                    # 7
    "Optic Disc",              # 8
    "Retinal Vessels",         # 9
    "Fovea",                   # 10
    "Retinal Boundary",        # 11
]


def load_split_ids(split_file):
    """Load image IDs from a split file, ignoring comments and blank lines."""
    ids = []
    with open(split_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                ids.append(line)
    return ids


def dice_coefficient(pred, gt, smooth=1e-7):
    """
    Compute Dice coefficient for a single class.

    Args:
        pred: Binary prediction mask (H, W)
        gt: Binary ground truth mask (H, W)
        smooth: Smoothing factor to avoid division by zero

    Returns:
        Dice score (float)
    """
    intersection = np.sum(pred * gt)
    return (2.0 * intersection + smooth) / (np.sum(pred) + np.sum(gt) + smooth)


def iou_coefficient(pred, gt, smooth=1e-7):
    """
    Compute Intersection over Union for a single class.

    Args:
        pred: Binary prediction mask (H, W)
        gt: Binary ground truth mask (H, W)
        smooth: Smoothing factor

    Returns:
        IoU score (float)
    """
    intersection = np.sum(pred * gt)
    union = np.sum(pred) + np.sum(gt) - intersection
    return (intersection + smooth) / (union + smooth)


def hausdorff_distance_95(pred, gt):
    """
    Compute 95th percentile Hausdorff Distance.

    Args:
        pred: Binary prediction mask (H, W)
        gt: Binary ground truth mask (H, W)

    Returns:
        HD95 value (float), or np.nan if either mask is empty
    """
    if np.sum(pred) == 0 or np.sum(gt) == 0:
        return np.nan

    # Compute distance transforms
    pred_boundary = pred.astype(bool) & ~(
        distance_transform_edt(pred.astype(bool)) > 1
    )
    gt_boundary = gt.astype(bool) & ~(
        distance_transform_edt(gt.astype(bool)) > 1
    )

    if np.sum(pred_boundary) == 0 or np.sum(gt_boundary) == 0:
        return np.nan

    # Distance from pred boundary to gt
    dist_gt = distance_transform_edt(~gt_boundary)
    dist_pred = distance_transform_edt(~pred_boundary)

    d_pred_to_gt = dist_gt[pred_boundary]
    d_gt_to_pred = dist_pred[gt_boundary]

    all_distances = np.concatenate([d_pred_to_gt, d_gt_to_pred])
    return np.percentile(all_distances, 95)


def compute_aupr(pred_prob, gt, num_classes):
    """
    Compute per-class Area Under Precision-Recall Curve.

    Args:
        pred_prob: Softmax probability map (H, W, C)
        gt: Ground truth label map (H, W)
        num_classes: Number of classes

    Returns:
        Dictionary of per-class AUPR values
    """
    aupr_per_class = {}
    gt_flat = gt.flatten()
    for c in range(num_classes):
        gt_binary = (gt_flat == c).astype(int)
        if np.sum(gt_binary) == 0:
            aupr_per_class[c] = np.nan
            continue
        pred_c = pred_prob[:, :, c].flatten()
        aupr_per_class[c] = average_precision_score(gt_binary, pred_c)
    return aupr_per_class


def evaluate_segmentation(pred_dir, gt_dir, split_ids, num_classes=12):
    """
    Evaluate segmentation performance across all test images.

    Args:
        pred_dir: Directory containing prediction masks (.npy or .png)
        gt_dir: Directory containing ground truth masks
        split_ids: List of image IDs to evaluate
        num_classes: Number of segmentation classes

    Returns:
        Dictionary with mDice, mIoU, per-class Dice, HD95 results
    """
    all_dice = defaultdict(list)
    all_iou = defaultdict(list)
    all_hd95 = defaultdict(list)
    per_image_mdice = {}

    for img_id in split_ids:
        # Load prediction and ground truth
        pred_path = os.path.join(pred_dir, f"{img_id}_pred.npy")
        gt_path = os.path.join(gt_dir, f"{img_id}_mask.npy")

        if not os.path.exists(pred_path):
            print(f"Warning: Prediction not found for {img_id}, skipping.")
            continue
        if not os.path.exists(gt_path):
            print(f"Warning: Ground truth not found for {img_id}, skipping.")
            continue

        pred = np.load(pred_path)  # (H, W) integer labels or (H, W, C) probabilities
        gt = np.load(gt_path)      # (H, W) integer labels

        # If pred is probabilities, take argmax
        if pred.ndim == 3:
            pred_labels = np.argmax(pred, axis=-1)
        else:
            pred_labels = pred

        image_dice_scores = []
        for c in range(num_classes):
            pred_c = (pred_labels == c).astype(np.float32)
            gt_c = (gt == c).astype(np.float32)

            # Skip classes not present in ground truth AND prediction
            if np.sum(gt_c) == 0 and np.sum(pred_c) == 0:
                continue

            d = dice_coefficient(pred_c, gt_c)
            j = iou_coefficient(pred_c, gt_c)
            h = hausdorff_distance_95(pred_c, gt_c)

            all_dice[c].append(d)
            all_iou[c].append(j)
            all_hd95[c].append(h)
            image_dice_scores.append(d)

        per_image_mdice[img_id] = np.mean(image_dice_scores) if image_dice_scores else 0.0

    # Compute mean metrics
    results = {
        'per_class_dice': {},
        'per_class_iou': {},
        'per_class_hd95': {},
        'per_image_mdice': per_image_mdice,
    }

    valid_dice = []
    valid_iou = []
    for c in range(num_classes):
        if c in all_dice and len(all_dice[c]) > 0:
            mean_d = np.mean(all_dice[c])
            std_d = np.std(all_dice[c])
            mean_j = np.mean(all_iou[c])
            hd95_vals = [v for v in all_hd95[c] if not np.isnan(v)]
            mean_h = np.mean(hd95_vals) if hd95_vals else np.nan

            results['per_class_dice'][CLASS_NAMES[c]] = {
                'mean': mean_d, 'std': std_d
            }
            results['per_class_iou'][CLASS_NAMES[c]] = {'mean': mean_j}
            results['per_class_hd95'][CLASS_NAMES[c]] = {'mean': mean_h}
            valid_dice.append(mean_d)
            valid_iou.append(mean_j)

    results['mDice'] = np.mean(valid_dice) if valid_dice else 0.0
    results['mIoU'] = np.mean(valid_iou) if valid_iou else 0.0

    return results


def print_results(results):
    """Print formatted evaluation results."""
    print("=" * 70)
    print("SEGMENTATION EVALUATION RESULTS")
    print("=" * 70)
    print(f"\nmDice: {results['mDice']:.4f}")
    print(f"mIoU:  {results['mIoU']:.4f}")
    print(f"\n{'Class':<30} {'Dice (mean±std)':<20} {'IoU':<10} {'HD95':<10}")
    print("-" * 70)
    for cls_name in CLASS_NAMES:
        if cls_name in results['per_class_dice']:
            d = results['per_class_dice'][cls_name]
            j = results['per_class_iou'][cls_name]['mean']
            h = results['per_class_hd95'][cls_name]['mean']
            h_str = f"{h:.2f}" if not np.isnan(h) else "N/A"
            print(f"{cls_name:<30} {d['mean']:.4f}±{d['std']:.4f}      {j:.4f}     {h_str}")
    print("=" * 70)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate segmentation performance")
    parser.add_argument("--pred_dir", type=str, required=True,
                        help="Directory containing prediction masks")
    parser.add_argument("--gt_dir", type=str, required=True,
                        help="Directory containing ground truth masks")
    parser.add_argument("--split_file", type=str, required=True,
                        help="Path to split file with image IDs")
    parser.add_argument("--num_classes", type=int, default=12,
                        help="Number of segmentation classes (default: 12)")

    args = parser.parse_args()

    split_ids = load_split_ids(args.split_file)
    print(f"Evaluating {len(split_ids)} images...")

    results = evaluate_segmentation(
        args.pred_dir, args.gt_dir, split_ids, args.num_classes
    )
    print_results(results)
