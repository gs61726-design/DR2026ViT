"""
Classification Evaluation Script for APA-SegFormer
===================================================
Computes: Accuracy (with numerator/denominator), QWK, Macro AUC,
          PDR Sensitivity, PDR Specificity, Confusion Matrix

Equations from the paper:
    Acc = N_correct / N_total                               (Eq. 13)
    Se(PDR) = TP(PDR) / (TP(PDR) + FN(PDR))               (Eq. 14)
    Sp(PDR) = TN(PDR) / (TN(PDR) + FP(PDR))               (Eq. 15)

Usage:
    python eval_classification.py \
        --pred_file results/grading_preds.csv \
        --gt_file data/refined_idrid/grades.csv \
        --split_file splits/test_ids.txt
"""

import argparse
import numpy as np
import pandas as pd
from collections import OrderedDict

try:
    from sklearn.metrics import (
        accuracy_score,
        cohen_kappa_score,
        roc_auc_score,
        confusion_matrix,
    )
except ImportError:
    raise ImportError("scikit-learn is required. Install via: pip install scikit-learn")


GRADE_NAMES = {
    0: "No DR (Grade 0)",
    1: "Mild NPDR (Grade 1)",
    2: "Moderate NPDR (Grade 2)",
    3: "Severe NPDR (Grade 3)",
    4: "PDR (Grade 4)",
}

PDR_GRADE = 4  # Grade 4 = Proliferative DR


def load_split_ids(split_file):
    """Load image IDs from a split file, ignoring comments and blank lines."""
    ids = []
    with open(split_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                ids.append(line)
    return ids


def compute_accuracy(y_true, y_pred):
    """
    Compute accuracy with explicit numerator and denominator.
    Eq. (13): Acc = N_correct / N_total

    Returns:
        accuracy, n_correct, n_total
    """
    n_total = len(y_true)
    n_correct = int(np.sum(np.array(y_true) == np.array(y_pred)))
    accuracy = n_correct / n_total
    return accuracy, n_correct, n_total


def compute_qwk(y_true, y_pred):
    """
    Compute Quadratic Weighted Kappa.
    Measures agreement between predicted and true ordinal grades.
    """
    return cohen_kappa_score(y_true, y_pred, weights='quadratic')


def compute_macro_auc(y_true, y_pred_probs, num_classes=5):
    """
    Compute macro-averaged One-vs-Rest AUC.

    Args:
        y_true: True labels (N,)
        y_pred_probs: Predicted probabilities (N, num_classes)
        num_classes: Number of grading classes

    Returns:
        Macro AUC score
    """
    y_true_onehot = np.eye(num_classes)[np.array(y_true)]
    return roc_auc_score(y_true_onehot, y_pred_probs, multi_class='ovr',
                         average='macro')


def compute_pdr_sensitivity(y_true, y_pred):
    """
    Compute PDR (Grade 4) Sensitivity with numerator/denominator.
    Eq. (14): Se(PDR) = TP(PDR) / (TP(PDR) + FN(PDR))

    Returns:
        sensitivity, tp, tp+fn
    """
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)

    tp = int(np.sum((y_true == PDR_GRADE) & (y_pred == PDR_GRADE)))
    fn = int(np.sum((y_true == PDR_GRADE) & (y_pred != PDR_GRADE)))
    total = tp + fn

    if total == 0:
        return np.nan, 0, 0

    sensitivity = tp / total
    return sensitivity, tp, total


def compute_pdr_specificity(y_true, y_pred):
    """
    Compute PDR (Grade 4) Specificity with numerator/denominator.
    Eq. (15): Sp(PDR) = TN(PDR) / (TN(PDR) + FP(PDR))

    Returns:
        specificity, tn, tn+fp
    """
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)

    tn = int(np.sum((y_true != PDR_GRADE) & (y_pred != PDR_GRADE)))
    fp = int(np.sum((y_true != PDR_GRADE) & (y_pred == PDR_GRADE)))
    total = tn + fp

    if total == 0:
        return np.nan, 0, 0

    specificity = tn / total
    return specificity, tn, total


def evaluate_classification(pred_file, gt_file, split_ids, prob_file=None):
    """
    Evaluate classification performance on the specified split.

    Args:
        pred_file: CSV with columns [image_id, predicted_grade]
        gt_file: CSV with columns [image_id, true_grade]
        split_ids: List of image IDs to evaluate
        prob_file: Optional CSV with prediction probabilities for AUC

    Returns:
        Dictionary of all classification metrics
    """
    pred_df = pd.read_csv(pred_file)
    gt_df = pd.read_csv(gt_file)

    # Filter to split
    pred_df = pred_df[pred_df['image_id'].isin(split_ids)]
    gt_df = gt_df[gt_df['image_id'].isin(split_ids)]

    # Merge on image_id
    merged = gt_df.merge(pred_df, on='image_id', suffixes=('_true', '_pred'))
    y_true = merged['true_grade'].values if 'true_grade' in merged.columns else merged.iloc[:, 1].values
    y_pred = merged['predicted_grade'].values if 'predicted_grade' in merged.columns else merged.iloc[:, 2].values

    results = OrderedDict()

    # Accuracy (Eq. 13)
    acc, n_correct, n_total = compute_accuracy(y_true, y_pred)
    results['accuracy'] = acc
    results['accuracy_detail'] = f"{n_correct}/{n_total} = {acc*100:.2f}%"

    # QWK
    results['qwk'] = compute_qwk(y_true, y_pred)

    # Macro AUC (requires probability file)
    if prob_file and os.path.exists(prob_file):
        prob_df = pd.read_csv(prob_file)
        prob_df = prob_df[prob_df['image_id'].isin(split_ids)]
        prob_cols = [c for c in prob_df.columns if c.startswith('prob_')]
        y_pred_probs = prob_df[prob_cols].values
        results['macro_auc'] = compute_macro_auc(y_true, y_pred_probs)
    else:
        results['macro_auc'] = "N/A (probability file not provided)"

    # PDR Sensitivity (Eq. 14)
    se, tp, se_denom = compute_pdr_sensitivity(y_true, y_pred)
    results['pdr_sensitivity'] = se
    results['pdr_sensitivity_detail'] = f"{tp}/{se_denom} = {se*100:.2f}%"

    # PDR Specificity (Eq. 15)
    sp, tn, sp_denom = compute_pdr_specificity(y_true, y_pred)
    results['pdr_specificity'] = sp
    results['pdr_specificity_detail'] = f"{tn}/{sp_denom} = {sp*100:.2f}%"

    # Confusion Matrix
    cm = confusion_matrix(y_true, y_pred, labels=list(range(5)))
    results['confusion_matrix'] = cm

    return results


def print_results(results):
    """Print formatted classification results."""
    print("=" * 60)
    print("CLASSIFICATION EVALUATION RESULTS (5-class DR Grading)")
    print("=" * 60)
    print(f"\nAccuracy:          {results['accuracy_detail']}")
    print(f"QWK:               {results['qwk']:.4f}")
    print(f"Macro AUC:         {results['macro_auc']}")
    print(f"PDR Sensitivity:   {results['pdr_sensitivity_detail']}")
    print(f"PDR Specificity:   {results['pdr_specificity_detail']}")

    print(f"\nConfusion Matrix (rows=true, cols=predicted):")
    print(f"{'':>15}", end="")
    for g in range(5):
        print(f"  Grade {g}", end="")
    print()
    print("-" * 60)
    for i in range(5):
        print(f"  {GRADE_NAMES[i]:<25}", end="")
        for j in range(5):
            print(f"  {results['confusion_matrix'][i, j]:>5}", end="")
        print()
    print("=" * 60)


if __name__ == "__main__":
    import os

    parser = argparse.ArgumentParser(description="Evaluate classification performance")
    parser.add_argument("--pred_file", type=str, required=True,
                        help="CSV file with predicted grades")
    parser.add_argument("--gt_file", type=str, required=True,
                        help="CSV file with ground truth grades")
    parser.add_argument("--split_file", type=str, required=True,
                        help="Path to split file with image IDs")
    parser.add_argument("--prob_file", type=str, default=None,
                        help="Optional CSV with prediction probabilities for AUC")

    args = parser.parse_args()

    split_ids = load_split_ids(args.split_file)
    print(f"Evaluating {len(split_ids)} images...")

    results = evaluate_classification(
        args.pred_file, args.gt_file, split_ids, args.prob_file
    )
    print_results(results)
