"""
Statistical Significance Testing for APA-SegFormer
===================================================
Implements paired Wilcoxon signed-rank tests as described in the paper.

Test 1 (Section 3.3): Per-image OD-adjacent FPR comparison
    - Paired unit: per image
    - N = 27 paired test images
    - Compares proposed method vs. vanilla SegFormer-B3

Test 2 (Section 3.5): Per-image mDice across five-fold cross-validation
    - Paired unit: per image across folds
    - N = 54 paired observations (each image in its held-out fold)
    - Compares proposed method vs. each baseline

Usage:
    python wilcoxon_tests.py \
        --test fpr \
        --proposed_file results/proposed_fpr_per_image.csv \
        --baseline_file results/segformer_fpr_per_image.csv

    python wilcoxon_tests.py \
        --test crossval \
        --proposed_file results/proposed_cv_per_image_mdice.csv \
        --baseline_file results/segformer_cv_per_image_mdice.csv
"""

import argparse
import numpy as np
import pandas as pd

try:
    from scipy.stats import wilcoxon
except ImportError:
    raise ImportError("scipy is required. Install via: pip install scipy")


def load_paired_values(proposed_file, baseline_file, value_column='value'):
    """
    Load paired values from two CSV files.

    Expected CSV format:
        image_id,value
        IDRiD_055,0.089
        IDRiD_056,0.102
        ...

    Args:
        proposed_file: CSV with proposed method per-image values
        baseline_file: CSV with baseline method per-image values
        value_column: Name of the value column

    Returns:
        proposed_values, baseline_values (aligned numpy arrays)
    """
    proposed_df = pd.read_csv(proposed_file)
    baseline_df = pd.read_csv(baseline_file)

    # Merge on image_id to ensure alignment
    merged = proposed_df.merge(
        baseline_df, on='image_id', suffixes=('_proposed', '_baseline')
    )

    val_col_proposed = f"{value_column}_proposed"
    val_col_baseline = f"{value_column}_baseline"

    proposed_values = merged[val_col_proposed].values
    baseline_values = merged[val_col_baseline].values

    return proposed_values, baseline_values, merged['image_id'].values


def run_wilcoxon_test(proposed, baseline, test_name, alternative='two-sided'):
    """
    Run paired Wilcoxon signed-rank test.

    Args:
        proposed: Per-image values for proposed method (N,)
        baseline: Per-image values for baseline method (N,)
        test_name: Descriptive name for the test
        alternative: 'two-sided', 'greater', or 'less'

    Returns:
        Dictionary with test results
    """
    n_pairs = len(proposed)
    differences = proposed - baseline

    # Remove zero differences (tied pairs)
    non_zero_mask = differences != 0
    n_non_zero = np.sum(non_zero_mask)

    if n_non_zero < 2:
        print(f"Warning: Only {n_non_zero} non-zero differences. "
              f"Cannot perform Wilcoxon test.")
        return None

    stat, p_value = wilcoxon(proposed, baseline, alternative=alternative)

    results = {
        'test_name': test_name,
        'n_pairs': n_pairs,
        'n_non_zero_differences': int(n_non_zero),
        'statistic': stat,
        'p_value': p_value,
        'alternative': alternative,
        'mean_proposed': np.mean(proposed),
        'std_proposed': np.std(proposed),
        'mean_baseline': np.mean(baseline),
        'std_baseline': np.std(baseline),
        'mean_difference': np.mean(differences),
        'median_difference': np.median(differences),
    }

    return results


def print_results(results):
    """Print formatted test results."""
    if results is None:
        print("Test could not be performed (insufficient non-zero differences).")
        return

    print("=" * 65)
    print(f"PAIRED WILCOXON SIGNED-RANK TEST: {results['test_name']}")
    print("=" * 65)
    print(f"\n  Paired sample unit:     per image")
    print(f"  Number of pairs (N):    {results['n_pairs']}")
    print(f"  Non-zero differences:   {results['n_non_zero_differences']}")
    print(f"  Alternative hypothesis: {results['alternative']}")
    print(f"\n  Proposed method:  {results['mean_proposed']:.4f} ± {results['std_proposed']:.4f}")
    print(f"  Baseline method:  {results['mean_baseline']:.4f} ± {results['std_baseline']:.4f}")
    print(f"  Mean difference:  {results['mean_difference']:.4f}")
    print(f"  Median difference: {results['median_difference']:.4f}")
    print(f"\n  Test statistic (W):  {results['statistic']:.1f}")
    print(f"  p-value:             {results['p_value']:.6f}")

    if results['p_value'] < 0.001:
        sig = "*** (p < 0.001)"
    elif results['p_value'] < 0.01:
        sig = "** (p < 0.01)"
    elif results['p_value'] < 0.05:
        sig = "* (p < 0.05)"
    else:
        sig = "n.s."
    print(f"  Significance:        {sig}")
    print("=" * 65)


def run_fpr_test(proposed_file, baseline_file):
    """
    Section 3.3 test: Per-image OD-adjacent FPR on 27 test images.
    """
    proposed, baseline, image_ids = load_paired_values(
        proposed_file, baseline_file, value_column='od_fpr'
    )
    print(f"\nLoaded {len(proposed)} paired observations (expected: 27 test images)")
    results = run_wilcoxon_test(
        proposed, baseline,
        test_name="OD-Adjacent Exudate FPR (Section 3.3, N=27 test images)",
        alternative='two-sided'
    )
    print_results(results)
    return results


def run_crossval_test(proposed_file, baseline_file):
    """
    Section 3.5 test: Per-image mDice across five-fold CV on 54 training images.
    Each image appears in exactly one validation fold.
    """
    proposed, baseline, image_ids = load_paired_values(
        proposed_file, baseline_file, value_column='mdice'
    )
    print(f"\nLoaded {len(proposed)} paired observations (expected: 54 training images)")
    results = run_wilcoxon_test(
        proposed, baseline,
        test_name="Per-image mDice across 5-fold CV (Section 3.5, N=54 images)",
        alternative='two-sided'
    )
    print_results(results)
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Statistical significance tests for APA-SegFormer"
    )
    parser.add_argument("--test", type=str, required=True,
                        choices=['fpr', 'crossval'],
                        help="Which test to run: 'fpr' (Section 3.3) or "
                             "'crossval' (Section 3.5)")
    parser.add_argument("--proposed_file", type=str, required=True,
                        help="CSV with per-image values for proposed method")
    parser.add_argument("--baseline_file", type=str, required=True,
                        help="CSV with per-image values for baseline method")

    args = parser.parse_args()

    if args.test == 'fpr':
        run_fpr_test(args.proposed_file, args.baseline_file)
    elif args.test == 'crossval':
        run_crossval_test(args.proposed_file, args.baseline_file)
