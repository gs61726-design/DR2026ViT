"""
Wavelet-Guided Preprocessing Pipeline
======================================
Implements the dual-tree complex wavelet-guided preprocessing described
in Section 2.1 of the paper.

Steps:
    1. Extract green channel and normalize
    2. Two-level DTCWT decomposition
    3. CLAHE enhancement on low-frequency coefficients
    4. BayesShrink soft-thresholding on high-frequency coefficients
    5. Inverse DTCWT reconstruction

Usage:
    python dtcwt_preprocessing.py \
        --data_dir data/refined_idrid/images/ \
        --output_dir data/preprocessed/ \
        --split_file splits/train_ids.txt
"""

import argparse
import os
import numpy as np

try:
    import cv2
    import dtcwt
except ImportError as e:
    raise ImportError(f"Missing dependency: {e}. Install via: "
                      "pip install opencv-python dtcwt")


def extract_green_channel(image):
    """
    Extract and normalize the green channel from a BGR fundus image.

    Args:
        image: BGR image (H, W, 3), uint8

    Returns:
        Normalized green channel (H, W), float64 in [0, 1]
    """
    green = image[:, :, 1].astype(np.float64) / 255.0
    return green


def apply_clahe(coefficients, clip_limit=2.0, grid_size=(8, 8)):
    """
    Apply CLAHE to low-frequency wavelet coefficients.

    Args:
        coefficients: Low-frequency coefficients (H, W), float64
        clip_limit: CLAHE clip limit
        grid_size: CLAHE tile grid size

    Returns:
        Enhanced coefficients (H, W), float64
    """
    # Scale to uint8 for CLAHE
    coeff_min = coefficients.min()
    coeff_max = coefficients.max()
    if coeff_max - coeff_min < 1e-10:
        return coefficients

    scaled = ((coefficients - coeff_min) / (coeff_max - coeff_min) * 255).astype(np.uint8)

    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=grid_size)
    enhanced = clahe.apply(scaled)

    # Scale back to original range
    result = enhanced.astype(np.float64) / 255.0 * (coeff_max - coeff_min) + coeff_min
    return result


def bayes_shrink_threshold(coefficients):
    """
    Compute BayesShrink threshold for wavelet denoising.

    The BayesShrink threshold is:
        T = sigma_noise^2 / sigma_signal
    where:
        sigma_noise is estimated from the finest-scale coefficients
        sigma_signal = sqrt(max(sigma_total^2 - sigma_noise^2, 0))

    Args:
        coefficients: High-frequency wavelet coefficients

    Returns:
        Threshold value (float)
    """
    # Estimate noise sigma using MAD (Median Absolute Deviation)
    sigma_noise = np.median(np.abs(coefficients)) / 0.6745

    # Estimate total variance
    sigma_total_sq = np.var(coefficients)

    # Estimate signal variance
    sigma_signal_sq = max(sigma_total_sq - sigma_noise ** 2, 0)

    if sigma_signal_sq == 0:
        return np.max(np.abs(coefficients))  # Threshold everything

    sigma_signal = np.sqrt(sigma_signal_sq)
    threshold = (sigma_noise ** 2) / sigma_signal
    return threshold


def soft_threshold(coefficients, threshold):
    """
    Apply soft thresholding to wavelet coefficients.

    Args:
        coefficients: Complex or real wavelet coefficients
        threshold: Threshold value

    Returns:
        Thresholded coefficients
    """
    magnitude = np.abs(coefficients)
    # Soft thresholding
    shrunk_magnitude = np.maximum(magnitude - threshold, 0)
    # Preserve sign/phase
    with np.errstate(divide='ignore', invalid='ignore'):
        result = np.where(
            magnitude > 0,
            coefficients * shrunk_magnitude / magnitude,
            0
        )
    return result


def dtcwt_preprocess(image, n_levels=2, clahe_clip=2.0, clahe_grid=(8, 8)):
    """
    Full wavelet-guided preprocessing pipeline.

    Args:
        image: BGR fundus image (H, W, 3), uint8
        n_levels: Number of DTCWT decomposition levels
        clahe_clip: CLAHE clip limit
        clahe_grid: CLAHE tile grid size

    Returns:
        Preprocessed image (H, W), float64
    """
    # Step 1: Extract and normalize green channel
    green = extract_green_channel(image)

    # Step 2: Two-level DTCWT decomposition
    transform = dtcwt.Transform2d()
    result = transform.forward(green, nlevels=n_levels)

    # Step 3: CLAHE on low-frequency coefficients
    result.lowpass = apply_clahe(result.lowpass, clahe_clip, clahe_grid)

    # Step 4: BayesShrink soft-thresholding on high-frequency coefficients
    for level in range(n_levels):
        highpass = result.highpass[level]
        for orientation in range(highpass.shape[2]):
            coeff = highpass[:, :, orientation]
            threshold = bayes_shrink_threshold(coeff)
            highpass[:, :, orientation] = soft_threshold(coeff, threshold)
        result.highpass[level] = highpass

    # Step 5: Inverse DTCWT reconstruction
    reconstructed = transform.inverse(result)

    # Clip to valid range
    reconstructed = np.clip(reconstructed, 0, 1)

    return reconstructed


def preprocess_dataset(data_dir, output_dir, split_ids=None):
    """
    Preprocess all images in a directory.

    Args:
        data_dir: Input image directory
        output_dir: Output directory for preprocessed images
        split_ids: Optional list of image IDs to process (processes all if None)
    """
    os.makedirs(output_dir, exist_ok=True)

    if split_ids:
        image_files = [f"{img_id}.jpg" for img_id in split_ids]
    else:
        image_files = [f for f in os.listdir(data_dir)
                       if f.lower().endswith(('.jpg', '.png', '.tif', '.bmp'))]

    for img_file in image_files:
        img_path = os.path.join(data_dir, img_file)
        if not os.path.exists(img_path):
            print(f"Warning: {img_path} not found, skipping.")
            continue

        image = cv2.imread(img_path)
        if image is None:
            print(f"Warning: Could not read {img_path}, skipping.")
            continue

        preprocessed = dtcwt_preprocess(image)

        # Save as numpy array
        base_name = os.path.splitext(img_file)[0]
        out_path = os.path.join(output_dir, f"{base_name}_preprocessed.npy")
        np.save(out_path, preprocessed)

        # Also save a visualization (uint8 PNG)
        vis_path = os.path.join(output_dir, f"{base_name}_preprocessed.png")
        cv2.imwrite(vis_path, (preprocessed * 255).astype(np.uint8))

        print(f"Preprocessed: {img_file}")

    print(f"\nDone. Preprocessed {len(image_files)} images to {output_dir}")


def load_split_ids(split_file):
    """Load image IDs from a split file."""
    ids = []
    with open(split_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                ids.append(line)
    return ids


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Wavelet-guided preprocessing for fundus images"
    )
    parser.add_argument("--data_dir", type=str, required=True,
                        help="Directory containing input fundus images")
    parser.add_argument("--output_dir", type=str, required=True,
                        help="Directory to save preprocessed images")
    parser.add_argument("--split_file", type=str, default=None,
                        help="Optional split file to process specific images")
    parser.add_argument("--clahe_clip", type=float, default=2.0,
                        help="CLAHE clip limit (default: 2.0)")
    parser.add_argument("--dtcwt_levels", type=int, default=2,
                        help="Number of DTCWT levels (default: 2)")

    args = parser.parse_args()

    split_ids = None
    if args.split_file:
        split_ids = load_split_ids(args.split_file)
        print(f"Processing {len(split_ids)} images from {args.split_file}")

    preprocess_dataset(args.data_dir, args.output_dir, split_ids)
