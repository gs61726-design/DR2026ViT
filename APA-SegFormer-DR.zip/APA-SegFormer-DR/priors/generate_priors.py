"""
Anatomical Prior Map Generation
================================
Generates four anatomical prior maps as described in Section 2.2 and Table 2.

Prior maps (Eq. 1):
    A = concat(M_OD, M_V, M_F, M_R) ∈ R^{H×W×4}

Priors:
    1. Optic Disc (M_OD)     - Frozen SegFormer disc/cup segmenter (REFUGE)
    2. Retinal Vessels (M_V) - Frozen FR-UNet vessel model (DRIVE)
    3. Foveal Region (M_F)   - Geometric estimate from disc centroid
    4. Retinal Boundary (M_R)- Otsu thresholding + morphology

Leakage control:
    - All extractors are frozen (no training on Refined IDRiD)
    - Refined IDRiD images used only for inference
    - See Table 2 in the paper for full protocol

Usage:
    python generate_priors.py \
        --data_dir data/refined_idrid/images/ \
        --output_dir data/priors/ \
        --od_model_path models/frozen_od_segmenter.pth \
        --vessel_model_path models/frozen_vessel_segmenter.pth
"""

import argparse
import os
import numpy as np

try:
    import cv2
    from scipy.ndimage import binary_fill_holes, binary_dilation, binary_erosion
    from skimage.morphology import disk
    from skimage.filters import threshold_otsu
except ImportError as e:
    raise ImportError(f"Missing dependency: {e}. Install via: "
                      "pip install opencv-python scipy scikit-image")


def load_split_ids(split_file):
    """Load image IDs from a split file."""
    ids = []
    with open(split_file, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                ids.append(line)
    return ids


# ---------- Prior 1: Optic Disc ----------

def generate_optic_disc_prior(image, model=None, confidence_threshold=0.5,
                               dilation_fallback_px=10):
    """
    Generate optic disc prior map using a frozen disc segmenter.

    In practice, this uses a frozen SegFormer-based disc/cup segmenter
    pretrained on REFUGE (Dice = 0.95 on REFUGE validation set).

    Failure handling: Conservative dilation if confidence is low.

    Args:
        image: Fundus image (H, W, 3)
        model: Frozen OD segmentation model (if None, uses placeholder)
        confidence_threshold: Minimum confidence for valid detection
        dilation_fallback_px: Dilation pixels for low-confidence fallback

    Returns:
        Binary OD mask (H, W), float32
    """
    H, W = image.shape[:2]

    if model is not None:
        # ---- Production path: run frozen model ----
        # Preprocess for model input
        # pred = model.predict(image)
        # od_mask = (pred > confidence_threshold).astype(np.float32)
        #
        # # Failure handling: if confidence is low, apply conservative dilation
        # max_confidence = pred.max()
        # if max_confidence < confidence_threshold:
        #     od_mask = binary_dilation(od_mask, structure=disk(dilation_fallback_px))
        #     od_mask = od_mask.astype(np.float32)
        raise NotImplementedError(
            "Provide the frozen OD segmenter model. "
            "See Table 2 in the paper for training details."
        )
    else:
        # ---- Placeholder: morphological OD detection ----
        # This is a simplified fallback for demonstration.
        # Replace with the actual frozen model for reproduction.
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(gray)

        # Threshold bright region (OD is typically the brightest)
        _, bright_mask = cv2.threshold(enhanced, 0, 255,
                                        cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        # Find largest connected component as OD candidate
        bright_mask = bright_mask.astype(np.uint8)
        contours, _ = cv2.findContours(bright_mask, cv2.RETR_EXTERNAL,
                                        cv2.CHAIN_APPROX_SIMPLE)
        if contours:
            largest = max(contours, key=cv2.contourArea)
            od_mask = np.zeros((H, W), dtype=np.uint8)
            cv2.drawContours(od_mask, [largest], -1, 1, -1)
        else:
            od_mask = np.zeros((H, W), dtype=np.uint8)

        return od_mask.astype(np.float32)


# ---------- Prior 2: Retinal Vessels ----------

def generate_vessel_prior(image, model=None):
    """
    Generate retinal vessel prior map using a frozen FR-UNet model.

    In practice, this uses FR-UNet pretrained on DRIVE (AUC = 0.97).

    Failure handling: Morphological closing of thin gaps.

    Args:
        image: Fundus image (H, W, 3)
        model: Frozen vessel segmentation model (if None, uses placeholder)

    Returns:
        Binary vessel mask (H, W), float32
    """
    H, W = image.shape[:2]

    if model is not None:
        # ---- Production path: run frozen FR-UNet ----
        # pred = model.predict(image)
        # vessel_mask = (pred > 0.5).astype(np.float32)
        #
        # # Failure handling: morphological closing for thin gaps
        # vessel_mask = cv2.morphologyEx(
        #     vessel_mask.astype(np.uint8),
        #     cv2.MORPH_CLOSE, disk(2)
        # ).astype(np.float32)
        raise NotImplementedError(
            "Provide the frozen FR-UNet vessel model. "
            "See Table 2 in the paper for training details."
        )
    else:
        # ---- Placeholder: matched filter vessel detection ----
        green = image[:, :, 1]
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(green)

        # Simple vessel detection via morphological operations
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        opened = cv2.morphologyEx(enhanced, cv2.MORPH_OPEN, kernel)
        vessels = cv2.subtract(opened, enhanced)
        _, vessel_mask = cv2.threshold(vessels, 15, 1, cv2.THRESH_BINARY)

        # Morphological closing for thin gaps
        close_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        vessel_mask = cv2.morphologyEx(vessel_mask, cv2.MORPH_CLOSE, close_kernel)

        return vessel_mask.astype(np.float32)


# ---------- Prior 3: Foveal Region ----------

def generate_foveal_prior(od_mask, image_shape, expansion_factor=1.5):
    """
    Generate foveal region prior via geometric estimate from disc centroid.

    The fovea is estimated at approximately 2.5 disc diameters temporal
    to the optic disc center.

    Failure handling: Expanded region to avoid over-precision.

    Args:
        od_mask: Binary optic disc mask (H, W)
        image_shape: (H, W) of the image
        expansion_factor: Expansion multiplier for the foveal region radius

    Returns:
        Binary foveal region mask (H, W), float32
    """
    H, W = image_shape

    # Find OD centroid
    ys, xs = np.where(od_mask > 0)
    if len(xs) == 0:
        # Fallback: assume fovea is at image center
        cx, cy = W // 2, H // 2
        radius = min(H, W) // 20
    else:
        od_cx = int(np.mean(xs))
        od_cy = int(np.mean(ys))

        # Estimate OD diameter
        od_diameter = max(np.max(xs) - np.min(xs), np.max(ys) - np.min(ys))
        if od_diameter == 0:
            od_diameter = min(H, W) // 10

        # Fovea is ~2.5 OD diameters temporal to OD
        # Determine laterality (left vs right eye) from OD position
        if od_cx < W // 2:
            # OD on left → right eye → fovea is to the right
            cx = int(od_cx + 2.5 * od_diameter)
        else:
            # OD on right → left eye → fovea is to the left
            cx = int(od_cx - 2.5 * od_diameter)

        cy = od_cy
        radius = int(od_diameter * expansion_factor)

    # Clamp to image bounds
    cx = max(radius, min(cx, W - radius))
    cy = max(radius, min(cy, H - radius))

    # Create circular foveal mask
    Y, X = np.ogrid[:H, :W]
    foveal_mask = ((X - cx) ** 2 + (Y - cy) ** 2 <= radius ** 2).astype(np.float32)

    return foveal_mask


# ---------- Prior 4: Retinal Boundary ----------

def generate_retinal_boundary_prior(image):
    """
    Generate retinal boundary prior via Otsu thresholding and morphology.

    Failure handling: Border artifacts excluded.

    Args:
        image: Fundus image (H, W, 3)

    Returns:
        Binary retinal boundary mask (H, W), float32
    """
    H, W = image.shape[:2]

    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Otsu thresholding to separate retina from background
    threshold = threshold_otsu(gray)
    retina_mask = (gray > threshold * 0.5).astype(np.uint8)

    # Fill holes
    retina_mask = binary_fill_holes(retina_mask).astype(np.uint8)

    # Morphological operations to clean up
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15))
    retina_mask = cv2.morphologyEx(retina_mask, cv2.MORPH_CLOSE, kernel)
    retina_mask = cv2.morphologyEx(retina_mask, cv2.MORPH_OPEN, kernel)

    # Exclude border artifacts (5-pixel border)
    border_px = 5
    retina_mask[:border_px, :] = 0
    retina_mask[-border_px:, :] = 0
    retina_mask[:, :border_px] = 0
    retina_mask[:, -border_px:] = 0

    return retina_mask.astype(np.float32)


# ---------- Combined Prior Generation ----------

def generate_all_priors(image, od_model=None, vessel_model=None):
    """
    Generate all four anatomical prior maps and concatenate.

    A = concat(M_OD, M_V, M_F, M_R) ∈ R^{H×W×4}   (Eq. 1)

    Args:
        image: Fundus image (H, W, 3)
        od_model: Frozen OD segmenter (None for placeholder)
        vessel_model: Frozen vessel segmenter (None for placeholder)

    Returns:
        prior_tensor: (H, W, 4) float32 array
        individual_priors: dict of individual prior maps
    """
    H, W = image.shape[:2]

    # Generate individual priors
    od_mask = generate_optic_disc_prior(image, model=od_model)
    vessel_mask = generate_vessel_prior(image, model=vessel_model)
    foveal_mask = generate_foveal_prior(od_mask, (H, W))
    boundary_mask = generate_retinal_boundary_prior(image)

    # Concatenate (Eq. 1)
    prior_tensor = np.stack([od_mask, vessel_mask, foveal_mask, boundary_mask],
                            axis=-1)  # (H, W, 4)

    individual_priors = {
        'od': od_mask,
        'vessel': vessel_mask,
        'fovea': foveal_mask,
        'boundary': boundary_mask,
    }

    return prior_tensor, individual_priors


def process_dataset(data_dir, output_dir, split_ids=None):
    """
    Generate anatomical priors for all images.

    Args:
        data_dir: Input image directory
        output_dir: Output directory for prior maps
        split_ids: Optional list of specific image IDs to process
    """
    os.makedirs(output_dir, exist_ok=True)

    if split_ids:
        image_files = [f"{img_id}.jpg" for img_id in split_ids]
    else:
        image_files = [f for f in os.listdir(data_dir)
                       if f.lower().endswith(('.jpg', '.png', '.tif', '.bmp'))]

    for img_file in image_files:
        img_path = os.path.join(data_dir, img_file)
        if not os.path.exists(img_path):
            print(f"Warning: {img_path} not found, skipping.")
            continue

        image = cv2.imread(img_path)
        if image is None:
            print(f"Warning: Could not read {img_path}, skipping.")
            continue

        prior_tensor, individual_priors = generate_all_priors(image)
        base_name = os.path.splitext(img_file)[0]

        # Save concatenated prior tensor
        np.save(os.path.join(output_dir, f"{base_name}_priors.npy"), prior_tensor)

        # Save individual priors (for FPR evaluation)
        for prior_name, prior_map in individual_priors.items():
            np.save(os.path.join(output_dir, f"{base_name}_{prior_name}.npy"),
                    prior_map)

        print(f"Generated priors: {img_file}")

    print(f"\nDone. Generated priors for {len(image_files)} images in {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Generate anatomical prior maps for fundus images"
    )
    parser.add_argument("--data_dir", type=str, required=True,
                        help="Directory containing fundus images")
    parser.add_argument("--output_dir", type=str, required=True,
                        help="Directory to save prior maps")
    parser.add_argument("--split_file", type=str, default=None,
                        help="Optional split file to process specific images")
    parser.add_argument("--od_model_path", type=str, default=None,
                        help="Path to frozen OD segmenter weights")
    parser.add_argument("--vessel_model_path", type=str, default=None,
                        help="Path to frozen FR-UNet vessel weights")

    args = parser.parse_args()

    split_ids = None
    if args.split_file:
        split_ids = load_split_ids(args.split_file)

    process_dataset(args.data_dir, args.output_dir, split_ids)
